#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define BUFFER 1024
#define LECTURE  0
#define ECRITURE 1

static char* args[BUFFER];
pid_t pid;
static char* pwd; // current dir
static char ligne[BUFFER]; // commande a analyser
static int nbexecuteCmds = 0; // nombre de executeCmdes
char cwd[BUFFER]; // durrent dir
 
/*
 * fd: numero du file descriptor
 * premiere: 1 si premiere executeCmde dans la sequence
 * derniere: 1 si derniere executeCmde dans la sequence
 *
 * EXEMPLE avec la executeCmde "ls -l | head -n 2 | wc -l" :
 *    fd1  = executeCmd(0, 1, 0), with args[0] = "ls" and args[1] = "-l"
 *    fd2  = executeCmd(fd1, 0, 0), with args[0] = "grep" and args[1] = "-n" and args[2] = "2"
 *    fd3  = executeCmd(fd2, 0, 1), with args[0] = "wc" and args[1] = "-l"
 *
 */
static int executeCmd(int fd, int premiere, int derniere)
{
	//renvoi un FD
	int tubes[2];
 
	//creation des pipe et fils 
	pipe(tubes);	
	pid=fork();
 
	if (pid == 0) {
		
		//le fils 
		printf("(%d) Child exec <%s",getpid(),args[0]);
		
		for(int i=1;i<sizeof(args)/sizeof(args[0]); i++) {
			if (args[i] != NULL) printf(" %s",args[i]);
		}
		
		printf("> fd=%d premiere=%d derniere=%d\n",fd,premiere,derniere);
		
		if (fd == 0 && premiere == 1 && derniere == 0  ) {
			// pour la premiere executeCmde
			dup2( tubes[ECRITURE], STDOUT_FILENO );
		} else if (fd != 0 && premiere == 0 && derniere == 0 ) {
			// pour les executeCmdes du milieu
			dup2(fd, STDIN_FILENO);
			dup2(tubes[ECRITURE], STDOUT_FILENO);
		} else {
			// pour la derniere executeCmde
			dup2( fd, STDIN_FILENO );
		}
		if (execvp( args[0], args) == -1) {
			printf("Commande Inconnue : %s\n",args[0]);
			return 1; // si l'exec fail
		}
	}
	
	//nettoyage fd
	if (fd != 0) {		
	    close(fd); 
	}
 
	// plus rien ne doit etre ecrit
	close(tubes[ECRITURE]);
 
	// plus rien ne doit etre lu si il s'agit de la derniere executeCmde
	if (derniere == 1) {
		close(tubes[LECTURE]);
	}
	return tubes[LECTURE];
}
 
	//nombre de commandes a nettoyer
static void nettoyage(int n)
{
	int i;
	for (i = 0; i < n; ++i) 
		wait(NULL); 
}
 

  
static char* removeSpace(char* str)
{
	while ( isspace(*str) ) { ++str; }
	return str;
}
 
static void decoupe(char* cmd)
{
	//cette fonction remplis le tableau args proprement
	cmd = removeSpace(cmd); // on enleve les espaces multiples
	char* next = strchr(cmd, ' '); // on decoupe la string avec chaque espace
	int i = 0;
	while(next != NULL) { // tant qu un nouvel espace est present, 
		args[i] = cmd;
		next[0] = '\0';
		++i;
		cmd = removeSpace(next + 1);
		next = strchr(cmd, ' ');
	}
 
	if (cmd[0] != '\0') {
		args[i] = cmd;
		next = strchr(cmd, '\n');
		next[0] = '\0';
		++i; 
	}

	args[i] = NULL; // dernier arg de args = NULL
}

static int analyse(char* cmd, int fd, int premiere, int derniere)
{
	//printf("CMD= %s fd=%d premiere=%d derniere=%d\n",cmd,fd,premiere,derniere);
	decoupe(cmd); // decoupe la commande proprement dans le tableau d'args
	if (args[0] != NULL) {
		//executeCmdES SHELL
			//Implementation Exit
		if (strcmp(args[0], "exit") == 0) {
			return 0;
		}
			//Implementation CD
		else if (!strcmp(args[0], "cd")){
			if ((strcmp(args[1], "..")) == 0){
				chdir("..");
			}
			else if (strcmp(args[1],"..") != 0 ) {
				strcat(pwd,"/");
				strcat(pwd,args[1]);
				if(chdir(pwd) == -1) {
					printf("Cannot change directory \n"); 
				}   
			}
			//il faut ajouter ici si c'est un .tar ... et exec les commandes appropri�es
		}
		
		//Execution executeCmde
		else {		
		nbexecuteCmds += 1;
		return executeCmd(fd, premiere, derniere);
		}
	}
	return 0;
}

int main()
{
	printf("(%d) Lili's Shell\n",getpid());
	while (1) {
		pwd = getcwd(cwd, sizeof(cwd));
		// Prompt
		printf("%s$> ",pwd);
		fflush(NULL);
 
		// Lecture executeCmde
		if (!fgets(ligne, 1024, stdin)) {
			return 0; 
		}
 
		int fd = 0;
		int premiere = 1;
		char* cmd = ligne;
		char* next = strchr(cmd, '|'); // recherche du premier pipe 
 
		while (next != NULL) {
			// next => pipe
			*next = '\0';
			fd = analyse(cmd, fd, premiere, 0); // on lance une analyse des commandes precedant chaque pipe
			cmd = next + 1;
			next = strchr(cmd, '|'); // prochain pipe 
			premiere = 0;
		}
		fd = analyse(cmd, fd, premiere, 1); // on analyse la cmd avec derniere = 1
		nettoyage(nbexecuteCmds);
		nbexecuteCmds = 0;
	}
	return 0;
}