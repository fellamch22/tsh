let rev_append left right =
  let rec append left result =
    match left with
    | [] -> result
    | x :: xs -> append xs (x::result)
  in append left right;;

let rec less_than_greater n l less great = 
  match l with
  | [] -> rev_append (n::less) great
  | x :: xs -> if x < n then less_than_greater n xs (x::less) great
      else if x = n then rev_append less l
      else less_than_greater n [] less l
      
let insert x l =
  less_than_greater x l [] []
;; 

let sort l =
  let rec sort_aux l lt= 
    match l with 
    | [] -> lt
    | x :: xs -> sort_aux xs (insert x lt)
                   
  in sort_aux l []
;;

(*less_than_greater n l less great*)
let rec union_sorted l1 l2 =
  match l1 with
  | [] -> l2
  | x :: xs -> union_sorted xs (insert x l2);;

(* *)
let  inter_sorted l1 l2 = []
    (*let rec inter l1 l2 lt =
       match l1 with
       | [] -> lt
       | x :: xs -> if List.length(insert x l2) =  List.length(insert x l2) 
           then inter xs l2 (x::lt)
           else inter xs l2 lt
     in inter l1 l2 []*)
;;
